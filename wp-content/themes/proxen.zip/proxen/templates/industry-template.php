<div class="industry__content-box-item">
    <div class="industry__content-box-item-img"><img src="<?php echo get_template_directory_uri( ) . '/assets/img/industry.png' ?>" alt=""></div>
    <p class="h4_font"><?php the_title(); ?></p>
</div>